<meta charset="utf-8">
<title>Admin sskaura.com</title>

<!-- Favicon -->
<link rel="icon" href="<?=base_url()?>/Dependencies/Images/sskaura25.jpg" type="image/jpg">

<!-- Include Bootstrap-->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="<?php echo base_url(); ?>/Dependencies/Bootstrap/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>/Dependencies/Bootstrap/css/bootstrap.min.css">

<!-- Include Ionicons -->
<script src="https://unpkg.com/ionicons@4.5.10-1/dist/ionicons.js"></script>